
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(cors());

app.use(bodyParser.json());

mongoose.connect('mongodb+srv://wandersonthi:10Demaiovida@cluster0.1g0onws.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');


const notes = mongoose.model('Note', {
    token: String,
    notes: Array,
}, 'notes');

app.post('/api/persistir-dados', async (req, res) => {
    const { token, notes: reqNotes } = req.body;

    try {
   
        const existingRecord = await notes.findOne({ token });

        if (existingRecord) {
         
            const result = await notes.findOneAndUpdate(
                { token },
                { notes: reqNotes },
                { new: true } 
            );
            res.json({ message: 'Dados atualizados com sucesso!', result });
        } else {
       
            const result = await notes.create({ token, notes: reqNotes });
            res.json({ message: 'Dados persistidos com sucesso!', result });
        }
    } catch (error) {
        console.error('Erro ao persistir/atualizar dados:', error);
        res.status(500).json({ error: 'Erro ao persistir/atualizar dados' });
    }
});


app.get('/api/recuperar-dados/:token', async (req, res) => {
    const { token } = req.params;

    
    const result = await notes.findOne({ token });


    res.json(result ? result.notes : []);
});


app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
