
const openDB = () => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("AnotacoesDB", 1);


    request.onerror = (event) => {
      reject(`Erro ao abrir o banco de dados: ${event.target.error}`);
    };

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      db.createObjectStore("Anotacoes", { keyPath: "id", autoIncrement: true });
    };

    
    request.onsuccess = (event) => {
      resolve(event.target.result);
    };
  });
};


const adicionarAnotacao = (anotacao) => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      const transaction = db.transaction(["Anotacoes"], "readwrite");
      const notasStore = transaction.objectStore("Anotacoes");
      const addRequest = notasStore.add(anotacao);

  
      addRequest.onsuccess = () => {
        resolve("Anotação adicionada com sucesso!");
      };

      
      addRequest.onerror = () => {
        reject(`Erro ao adicionar anotação: ${addRequest.error}`);
      };
    } catch (error) {
      reject(`Erro ao abrir o banco de dados: ${error}`);
    }
  });
};

const editarAnotacao = (id, novosDados) => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      const transaction = db.transaction(["Anotacoes"], "readwrite");
      const notasStore = transaction.objectStore("Anotacoes");
      const anotacaoExistente = await notasStore.get(id);


      if (!anotacaoExistente) {
        reject(`Anotação com ID ${id} não encontrada.`);
        return;
      }


      const { text, potential, category, reminder } = anotacaoExistente;
      const anotacaoAtualizada = {
        id,
        text: novosDados.text || text,
        potential: novosDados.potential || potential,
        category: novosDados.category || category,
        reminder: novosDados.reminder || reminder,
      };

      const putRequest = notasStore.put(anotacaoAtualizada);

      putRequest.onsuccess = () => {
        resolve("Anotação editada com sucesso!");
      };

      putRequest.onerror = () => {
        reject(`Erro ao editar anotação: ${putRequest.error}`);
      };
    } catch (error) {
      reject(`Erro ao abrir o banco de dados: ${error}`);
    }
  });
};


const excluirAnotacao = (id) => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      const transaction = db.transaction(["Anotacoes"], "readwrite");
      const notasStore = transaction.objectStore("Anotacoes");
      const deleteRequest = notasStore.delete(id);

      deleteRequest.onsuccess = () => {
        resolve("Anotação excluída com sucesso!");
      };

 
      deleteRequest.onerror = () => {
        reject(`Erro ao excluir anotação: ${deleteRequest.error}`);
      };
    } catch (error) {
      reject(`Erro ao abrir o banco de dados: ${error}`);
    }
  });
};


const consultarAnotacoes = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      const transaction = db.transaction(["Anotacoes"], "readonly");
      const notasStore = transaction.objectStore("Anotacoes");
      const consulta = notasStore.getAll();

      consulta.onsuccess = () => {
        resolve(consulta.result);
      };

     
      consulta.onerror = () => {
        reject(`Erro ao consultar anotações: ${consulta.error}`);
      };
    } catch (error) {
      reject(`Erro ao abrir o banco de dados: ${error}`);
    }
  });
};


const consultarAnotacaoPorId = (id) => {
  return new Promise(async (resolve, reject) => {
    const db = await openDB();
    const transaction = db.transaction(["Anotacoes"], "readonly");
    const store = transaction.objectStore("Anotacoes");
    const getRequest = store.get(id);

   
    getRequest.onsuccess = (event) => {
      const anotacao = event.target.result;
      resolve(anotacao);
    };

    getRequest.onerror = (event) => {
      reject(new Error("Erro ao consultar a anotação por ID"));
    };
  });
};

const limparAnotacoes = () => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      const transaction = db.transaction(["Anotacoes"], "readwrite");
      const notasStore = transaction.objectStore("Anotacoes");
      const clearRequest = notasStore.clear();

     
      clearRequest.onsuccess = () => {
        resolve("Anotações excluídas com sucesso!");
      };

      clearRequest.onerror = () => {
        reject(`Erro ao limpar anotações: ${clearRequest.error}`);
      };
    } catch (error) {
      reject(`Erro ao abrir o banco de dados: ${error}`);
    }
  });
};


module.exports = {
  adicionarAnotacao,
  editarAnotacao,
  excluirAnotacao,
  consultarAnotacoes,
  consultarAnotacaoPorId,
  limparAnotacoes
};
